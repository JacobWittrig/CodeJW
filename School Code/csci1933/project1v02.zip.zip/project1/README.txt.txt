Note: Make sure to include a README.txt in your submission that contains the
following information (10 point deduction if missing):
Jacob Wittrig wittr049
Coded by myself
• How to compile and run your program
The program should be straightforward to compile. When the file is not in zip form, it can easily be run by opening the larger project file and then running the FractalDrawer main.
• Any assumptions
Standard assumptions, based on the syllabus
• Additional features that you implemented (if applicable)
None
• Any known bugs or defects in the program
The rectangle fractal looks like a triangle but is still made of rectangles
• Any outside sources (aside from course resources) consulted for ideas used in the project,
in the format:
– I searched up the documentation for "Color" in order to know the functions https://docs.oracle.com/javase/8/docs/api/java/awt/Color.html
I certify that the information contained in this
README file is complete and accurate. I have both read and followed
the course policies in the ‘Academic Integrity - Course Policy’ section of
the course syllabus.
Jacob Wittrig
//You may be penalized for a missing or incomplete README.