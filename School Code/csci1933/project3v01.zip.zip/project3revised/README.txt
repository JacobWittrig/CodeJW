Group members’ names and x500s
Jacob Wittrig wittr049
• How to compile and run your program
You should be able to just run the test cases on the LinkedList and Array classes. I had no problems with
running it.
• Any assumptions
I assumed that this is made mostly for strings and integers. I do not know how well it would run for
larger data such as files.
• Additional features that you implemented (if applicable)
I implemented a function which can check if a list is sorted. However, even though I am sure that these work
as intended, I do not think the sorting test cases work properly as they do not match these.
• Any known bugs or defects in the program
The is sorted test does not pass in linked list. No matter what I did, there were some that could not be passed.
In the linked list two empty lists were passed in, and for some reason one was true and one was false in the test
cases.
• Any outside sources (aside from course resources) consulted for ideas used in the project, in
the format:
– How to clone array: https://stackoverflow.com/questions/1564832/how-do-i-do-a-deep-copy-of-a-2d-array-in-java
– How to index array: https://stackoverflow.com/questions/1128723/how-do-i-determine-whether-an-array
-contains-a-particular-value-in-java


• Include the statement: “I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.” and
type your name(s) underneath.
Jacob Wittrig