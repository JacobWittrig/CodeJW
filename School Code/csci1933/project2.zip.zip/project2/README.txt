Group members’ names and x500s
Worked by myself (Jacob Wittrig, wittr049)
• How to compile and run your program
For the tests, use the testing as described in the grading rubric. To run, use the main in Game.java as described. This will begin a new game of chess.
• Any assumptions
I assumed it was okay to do the path checking (ie to see if the way is open for a piece) in the isHorizontal and isVertical and isDiagonal, rather than the isLegalMove parts of each piece class. This reduced the redundancy, but means that the piece classes.
• Additional features that you implemented (if applicable)
None that I can think of, except for additional error handling, such as invalid inputs.
• Any known bugs or defects in the program
None that I know of
• Any outside sources (aside from course resources) consulted for ideas used in the project, in
the format:
– Learning how to get integers from a string: https://stackoverflow.com/questions/32659736/get-multiple-integer-values-from-a-string
– Figuring out why my scanners were giving errors: https://stackoverflow.com/questions/13042008/java-util-nosuchelementexception-scanner-reading-user-input

• Include the statement: “I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.” and
type your name(s) underneath.
Jacob Wittrig

